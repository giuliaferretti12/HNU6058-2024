---
title: About
description: There are many variations of passages of Lorem Ipsum available.
eleventyNavigation:
  key: About
  order: 1
disclaimer:
  text: This is a text disclaimer. It will be visible on the page.
---

<img src="/images/kitty.jpg" alt="" class="myphoto" />

I'm {{ siteConfig.author.name }}.

**{{ siteConfig.site.title }}** is my blog.

There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text.

Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source.

Image credit: [Orange Tabby Cat on Brown Knitted Textile by Alena Koval](https://www.pexels.com/photo/orange-tabby-cat-on-brown-knitted-textile-982300/)
