---
title: Sample page with custom permalink
description: All posts published since the start of of the blog back in 2020.
customPermalink: /custom-permalink/
eleventyNavigation:
  key: Custom permalink page
  order: 4
---

This is a sample page with a custom permalink and different title shown in menus.

Normally, post and page permalinks are derived from page titles. But in certain situations it makes sense to override that. With `customPermalink` property in front matter data it's possible. :)
