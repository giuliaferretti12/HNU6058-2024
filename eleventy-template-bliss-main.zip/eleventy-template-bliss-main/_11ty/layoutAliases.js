module.exports = {
  base: 'layouts/base.njk',
  page: 'layouts/page.njk',
  post: 'layouts/post.njk',
};
