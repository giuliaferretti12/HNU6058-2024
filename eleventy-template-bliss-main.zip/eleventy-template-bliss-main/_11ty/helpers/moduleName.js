const path = require('path');
module.exports = (name) => path.basename(name, '.js');
